self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3d8011f701aefc10b64aaa08bfb955d0",
    "url": "./index.html"
  },
  {
    "revision": "a200dfa0447ba6893dfb",
    "url": "./static/css/main.34de6062.chunk.css"
  },
  {
    "revision": "06324019b827357c2185",
    "url": "./static/js/2.750865dd.chunk.js"
  },
  {
    "revision": "a200dfa0447ba6893dfb",
    "url": "./static/js/main.b31443b6.chunk.js"
  },
  {
    "revision": "5e2f18a89cca2ba7dcf3",
    "url": "./static/js/runtime-main.03afd7db.js"
  },
  {
    "revision": "3213f1aec7f7da6a006760a8a0f75883",
    "url": "./static/media/malt.3213f1ae.svg"
  }
]);