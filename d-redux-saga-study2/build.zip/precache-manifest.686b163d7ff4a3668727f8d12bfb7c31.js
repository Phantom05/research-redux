self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e7bd4eeeea314058c9570d152194b845",
    "url": "./index.html"
  },
  {
    "revision": "d911de8cb91845db36b3",
    "url": "./static/css/main.34de6062.chunk.css"
  },
  {
    "revision": "65f4bf1db21fdfd317c8",
    "url": "./static/js/2.83d9f3cc.chunk.js"
  },
  {
    "revision": "d911de8cb91845db36b3",
    "url": "./static/js/main.e5f928dc.chunk.js"
  },
  {
    "revision": "5e2f18a89cca2ba7dcf3",
    "url": "./static/js/runtime-main.03afd7db.js"
  },
  {
    "revision": "3213f1aec7f7da6a006760a8a0f75883",
    "url": "./static/media/malt.3213f1ae.svg"
  }
]);